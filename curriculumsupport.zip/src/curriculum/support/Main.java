package curriculum.support;

import curriculum.support.GuiUtil.HomeWindow.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Main extends JFrame implements ActionListener {


    private static Main applicationInstance;
    private JTabbedPane applicationTabbedPanel;



    JComponent homePanel=null;
    public JComponent getHomePanel() {
        return homePanel;
    }
    public void setHomePanel(JComponent homePanel) {

        this.homePanel = homePanel;
        this.homePanel=new JPanel();
        this.homePanel.setLayout(new BorderLayout());
        this.homePanel.setBackground(Color.PINK);
        this.homePanel.add(new Heading(),BorderLayout.NORTH);
        this.homePanel.add(new Universities(),BorderLayout.WEST);
        this.homePanel.add(new KeyFeatures(),BorderLayout.EAST);
        this.homePanel.add(new LogInWindow(),BorderLayout.CENTER);
        this.homePanel.add(new Notice(),BorderLayout.SOUTH);
    }

    public JTabbedPane getApplicationTabbedPanel() {
        return applicationTabbedPanel;
    }

    public void setApplicationTabbedPanel(JTabbedPane tabPane,JPanel pane) {
        tabPane.add(pane);
    }


    private static Container content;


    private JMenu curriculumMenu;
    private JMenuItem logoutMenuItem;
    private JMenuItem exitMenuItem;
    private JMenu helpMenu;
    private JMenuItem infoMenuItem;

    public static Main getMainFrame(){
        if(applicationInstance==null)
            applicationInstance=new Main();
        return applicationInstance;
    }

    public void createMainWindow(){
        //Main Frame Specifications
        setTitle("Curriculum Support.");
        setLayout(new BorderLayout());
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int screen_width= (int)dim.getWidth();
        int screen_height= (int)dim.getHeight();
        setSize(screen_width, screen_height-40);

        //Settingup Cntent Pane
        content=getContentPane();
        content.setBackground(Color.blue);
        setJMenuBar(createJMenuBar());

        //Component for Tabed Pane
        //Initializing Tab Component container


        JPanel rightPanel=new JPanel();
        rightPanel.setBackground(Color.GRAY);

        JPanel leftPanel=new JPanel();
        leftPanel.setBackground(Color.GRAY);

        JPanel topPanel=new JPanel();
        topPanel.setBackground(Color.GRAY);

        JPanel bottomPanel=new JPanel();
        bottomPanel.setBackground(Color.GRAY);

        ImageIcon homeTabIcon=new ImageIcon("resource/Home16.gif");

        setHomePanel(homePanel);

        //applicationTabbedPanel.addTab("Home",homeTabIcon,getHomePanel());
        HomeTab.getInstanceHomeTab().addTab("Home",homeTabIcon,getHomePanel());
        add(HomeTab.getInstanceHomeTab(),BorderLayout.CENTER);



        add(rightPanel,BorderLayout.EAST);
        add(leftPanel,BorderLayout.WEST);
        add(topPanel,BorderLayout.NORTH);
        add(bottomPanel,BorderLayout.SOUTH);
        Image icon=Toolkit.getDefaultToolkit().getImage("resource/logo.png");
        setIconImage(icon);

        setVisible(true);

        addWindowListener( new WindowAdapter(){
            public void windowClosing (WindowEvent ev ) {
                int choice = JOptionPane.showOptionDialog(null,
                        "Do you really want to exit the system",
                        "Exit", JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,
                        null,null,null);
                if(choice == JOptionPane.YES_OPTION){
                    System.exit(0);
                }

                else if (choice==JOptionPane.NO_OPTION){

                }
            }
        });
    }
    private JMenuBar createJMenuBar(){
        JMenuBar menuBar = new JMenuBar();
        curriculumMenu = new JMenu("Curriculum");

        logoutMenuItem=new JMenuItem("Logout");
        logoutMenuItem.setActionCommand("Logout");
        logoutMenuItem.setEnabled(false);
        logoutMenuItem.addActionListener(this);
        curriculumMenu.add(logoutMenuItem);

        exitMenuItem=new JMenuItem("Exit");
        exitMenuItem.setActionCommand("Exit");
        exitMenuItem.addActionListener(this);
        curriculumMenu.add(exitMenuItem);


        helpMenu = new JMenu("Help");
        helpMenu.setActionCommand("help");
        helpMenu.addActionListener(this);

        infoMenuItem=new JMenuItem("Info");
        infoMenuItem.setActionCommand("info");
        infoMenuItem.addActionListener(this);
        helpMenu.add(infoMenuItem);

        menuBar.add(curriculumMenu);
        menuBar.add(helpMenu);
        return menuBar;
    }
    public static void main(String[] args){
        System.out.println("Starting Curriculum Support..........");
        Main.getMainFrame().createMainWindow();
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
