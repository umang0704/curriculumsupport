package curriculum.support.GuiUtil.User;

import curriculum.support.DbUtil.DbUtil_User;
import curriculum.support.DbUtil.RuntimePropertiesNewUser;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UserRegistration extends JPanel implements ActionListener {
//    JButton closeButton=null;
    private JLabel imageLabel=null;
    private JPanel userDetailsPanel=null;

    private JLabel emailLabel=null;
    private JLabel passwordLabel=null;
    private JLabel reEnterPasswordLabel=null;

    private JTextField emailTextField=null;
    private JPasswordField passwordTextField=null;
    private JPasswordField reEnterPasswordField=null;
    private JButton submitButton=null;
    private JButton cancelButton=null;

    private JInternalFrame emailPassInternalFrame=null;
    private JDesktopPane registrationDesktopPane=null;


    public UserRegistration(){
        super(new BorderLayout());

        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int screen_width= (int)dim.getWidth();
        int screen_height= (int)dim.getHeight();

        setSize(screen_width, screen_height-40);
        TitledBorder titledBorder=new TitledBorder("<html><Font color=black size=3><b>Registration:</b></font></html>");
        setBorder(titledBorder);

        JPanel imagePanel=new JPanel();
        imagePanel.setSize(screen_width, 200);
        imagePanel.setBackground(Color.WHITE);
        imagePanel.setLayout(new BorderLayout());
        imagePanel.add(imageLabel(),BorderLayout.CENTER);

        registrationDesktopPane=new JDesktopPane();
        TitledBorder newtitledBorder=new TitledBorder("<html><Font color=black size=3><b>Registration:</b></font></html>");
        registrationDesktopPane.setBorder(newtitledBorder);
        registrationDesktopPane.setBackground(new Color(218, 223, 235));
        registrationDesktopPane.add(addUserDetailsPanel());
       //registrationDesktopPane.add(new AddUserDetails());

        add(imagePanel,BorderLayout.NORTH);
        add(registrationDesktopPane,BorderLayout.CENTER);

        setVisible(true);
    }
    private JLabel imageLabel(){
        imageLabel=new JLabel(new ImageIcon("resource/userRegistration.png"));
        imageLabel.setSize(100,100);
        imageLabel.setBackground(Color.WHITE);
        return imageLabel;
    }
    private  JInternalFrame addUserDetailsPanel(){
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int screen_width= (int)dim.getWidth();
        int screen_height= (int)dim.getHeight();

        emailPassInternalFrame=new JInternalFrame("Unique User Auth.",true,false,false);
        emailPassInternalFrame.setLayout(new BorderLayout());


        userDetailsPanel=new JPanel();
        userDetailsPanel.setSize(200, 200);
        userDetailsPanel.setLayout(new GridLayout(4, 2, 5, 5));

        TitledBorder titledBorder=new TitledBorder("<html><Font color=black size=3><b>Email Registration:</b></font></html>");
        setBorder(titledBorder);

        emailLabel=new JLabel("Enter Email:");
        emailTextField=new JTextField();
        emailTextField.setSize(100, 20);

        passwordLabel=new JLabel("Enter Password:");
        passwordTextField=new JPasswordField();
        passwordTextField.setSize(100, 20);

        reEnterPasswordLabel=new JLabel("Re-Enter Password:");
        reEnterPasswordField=new JPasswordField();
        reEnterPasswordField.setSize(100, 20);

        submitButton=new JButton("Submit");
        submitButton.addActionListener(this);
        submitButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        submitButton.setActionCommand("submit");

        cancelButton=new JButton("Cancel");
        cancelButton.addActionListener(this);
        cancelButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        cancelButton.setActionCommand("cancel");

        userDetailsPanel.add(emailLabel);
        userDetailsPanel.add(emailTextField);
        userDetailsPanel.add(passwordLabel);
        userDetailsPanel.add(passwordTextField);
        userDetailsPanel.add(reEnterPasswordLabel);
        userDetailsPanel.add(reEnterPasswordField);
        userDetailsPanel.add(cancelButton);
        userDetailsPanel.add(submitButton);

        emailPassInternalFrame.add(userDetailsPanel,BorderLayout.CENTER);
        emailPassInternalFrame.setSize(450, 150);
        emailPassInternalFrame.setLocation(450, 50);
        emailPassInternalFrame.setVisible(true);

        return emailPassInternalFrame;
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand().equals("submit")){
            DbUtil_User objDbUtilUser =new DbUtil_User();
            String enteredEmail=emailTextField.getText();

            if(objDbUtilUser.uniqueUserAuthentication(enteredEmail)){
                System.out.println("unique User");
                String enteredPassword=passwordTextField.getText();
                String reEnteredPassword=reEnterPasswordField.getText();
                if(enteredPassword.equals(reEnteredPassword)){
                    boolean addedSuccesfully= objDbUtilUser.addUniqueUserDetails(enteredEmail, enteredPassword);
                   if(addedSuccesfully){
                       RuntimePropertiesNewUser.getInstance().setEmail_id(enteredEmail);
                       emailPassInternalFrame.setVisible(false);
                       registrationDesktopPane.add(new AddUserDetails());
                   }
                }else{
                    passwordTextField.setText("");
                    reEnterPasswordField.setText("");
                    JOptionPane.showMessageDialog(this,"Entered Password and Re-Entered Password do not match. Please Re-Enter. ");
                }
            }else{
                System.out.println("userExist");
                emailTextField.setText("");
                passwordTextField.setText("");
                reEnterPasswordField.setText("");
                JOptionPane.showMessageDialog(this,"User already EXIST. Try another Email.");
        }

    }
}
}
