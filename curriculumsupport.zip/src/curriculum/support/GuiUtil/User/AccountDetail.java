package curriculum.support.GuiUtil.User;

import curriculum.support.DbUtil.DbUtil_University;
import curriculum.support.DbUtil.DbUtil_User;
import curriculum.support.DbUtil.RuntimePropertiesExistingUsers;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class AccountDetail extends JDesktopPane implements MouseListener {
    DbUtil_User objDbUtilUser=new DbUtil_User();
    JInternalFrame courseDetails=null;
    JInternalFrame univ =null;
    JInternalFrame welcomePanel=null;

    public AccountDetail(){
        add(topPanel());
        add(welcome());
        setVisible(true);
    }

    public JInternalFrame topPanel(){
        JInternalFrame frame=new JInternalFrame("Account Detail",false,false,false,false);
        frame.setLocation(135,0);

        JPanel top=new JPanel();
        top.setLayout(new BorderLayout());
        top.setBackground(Color.WHITE);
        TitledBorder titledBorder = new TitledBorder("<html><Font color=black size=3><b>Account Details:</b></font></html>");
        top.setBorder(titledBorder);

        JPanel userDetails=null;
        userDetails=new JPanel();
        userDetails.setLayout(new GridLayout(5, 2, 2, 2));
        userDetails.setBackground(new Color(163, 198, 255));

        String uniName=objDbUtilUser.getUniversityNameFromCode(RuntimePropertiesExistingUsers.getInstance().getUnivId());
        String instName=objDbUtilUser.getInstituteNameFromCode(RuntimePropertiesExistingUsers.getInstance().getInstId());
        String courseName=objDbUtilUser.getCourseNameFromCode(RuntimePropertiesExistingUsers.getInstance().getCourseId());
        String branchName=objDbUtilUser.getBranchName(RuntimePropertiesExistingUsers.getInstance().getBranch());



        JLabel name=new JLabel("Name: "+RuntimePropertiesExistingUsers.getInstance().getName());
        JLabel address=new JLabel("Address: "+RuntimePropertiesExistingUsers.getInstance().getAddress());
        JLabel dob=new JLabel("DOB: "+RuntimePropertiesExistingUsers.getInstance().getDob());
        JLabel  gender=new JLabel("Gender: "+RuntimePropertiesExistingUsers.getInstance().getGender());
        JLabel contact=new JLabel("Contact: "+RuntimePropertiesExistingUsers.getInstance().getContact());
        JLabel university=new JLabel("University: "+uniName);
        JLabel institute=new JLabel("Institute: "+instName);
        JLabel course=new JLabel("Course: "+courseName);
        JLabel branch=new JLabel("Branch: "+branchName);

        userDetails.add(name);
        userDetails.add(university);
        userDetails.add(address);
        userDetails.add(institute);
        userDetails.add(dob);
        userDetails.add(course);
        userDetails.add(gender);
        userDetails.add(branch);
        userDetails.add(contact);

        JPanel utility=new JPanel();
        utility.setLayout(new GridLayout(1, 3, 1, 1));
        utility.setBackground(Color.WHITE);
        JLabel uniDetail=new JLabel("University Details");
        uniDetail.setForeground(Color.BLUE);
        uniDetail.addMouseListener(this);
        uniDetail.setCursor(new Cursor(Cursor.HAND_CURSOR));
        uniDetail.setName("University Details");

        JLabel courseDetail=new JLabel("Course Details");
        courseDetail.setForeground(Color.BLUE);
        courseDetail.addMouseListener(this);
        courseDetail.setCursor(new Cursor(Cursor.HAND_CURSOR));
        courseDetail.setName("Course Details");

        JLabel reset=new JLabel("Reset Info. Panel");
        reset.setForeground(Color.BLUE);
        reset.addMouseListener(this);
        reset.setCursor(new Cursor(Cursor.HAND_CURSOR));
        reset.setName("Reset Info. Panel");

        utility.add(uniDetail);
        utility.add(courseDetail);
        utility.add(reset);

        top.add(userDetails,BorderLayout.CENTER);
        top.add(utility,BorderLayout.SOUTH);

        frame.add(top);
        frame.setSize(800, 150);
        frame.setLocation(450, 0);
        frame.setVisible(true);
        return frame;
    }
    public JInternalFrame coursePane(){
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int screen_width= (int)dim.getWidth();
        int screen_height= (int)dim.getHeight();
        courseDetails=new JInternalFrame("Course Info.",false,false,false,false);

        JEditorPane editorPane=new JEditorPane();

        editorPane.setEditable(false);

        try{
            editorPane.setContentType("text/html");
            editorPane.setText(new DbUtil_University().getCoursePage(RuntimePropertiesExistingUsers.getInstance().getCourseId()));
        }catch(Exception e){
            System.out.println(e);
        }
        if (editorPane.getText().trim().equals("")){
            JOptionPane.showMessageDialog(this, "Information not updated");
        }
        JScrollPane scrollPane=new JScrollPane(editorPane);

        courseDetails.add(scrollPane);
        courseDetails.setSize(screen_width-30, screen_height-300);
        courseDetails.setLocation(0, 155);
        courseDetails.setVisible(true);
        return courseDetails;
    }

    public JInternalFrame univPane(){
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int screen_width= (int)dim.getWidth();
        int screen_height= (int)dim.getHeight();
        univ=new JInternalFrame("University Info.",false,false,false,false);


        JEditorPane editorPane=new JEditorPane();

        editorPane.setEditable(false);

        try{
            editorPane.setContentType("text/html");
            editorPane.setText(new DbUtil_University().getUnivPage(RuntimePropertiesExistingUsers.getInstance().getUnivId()));
        }catch(Exception e){
            System.out.println(e);
        }
        if (editorPane.getText().trim().equals("")){
            JOptionPane.showMessageDialog(this, "Information not updated");
        }

        JScrollPane scrollPane=new JScrollPane(editorPane);

        univ.add(scrollPane);
        univ.setSize(screen_width-30, screen_height-300);
        univ.setLocation(0, 155);
        univ.setVisible(true);
        return univ;
    }

    public JInternalFrame welcome(){
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int screen_width= (int)dim.getWidth();
        int screen_height= (int)dim.getHeight();

        welcomePanel=new JInternalFrame();

        JEditorPane editorPane=new JEditorPane();
        editorPane.setEditable(false);
        try{
            editorPane.setContentType("text/html");
            editorPane.setText("<!DOCTYPE html>\n" +
                    "<html lang=\"en\" dir=\"ltr\">\n" +
                    "  <head>\n" +
                    "    <meta charset=\"utf-8\">\n" +
                    "    <title></title>\n" +
                    "  </head>\n" +
                    "  <body>\n" +
                    "\n" +
                    "  <img src=\"https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcReBtGMuEFVwUbDCX8A1NAOwarTefnjkGdfnt-rw4Jlw1BYTj_G&usqp=CAU\" alt=\"Network Error\" height=\"300\" width=\"600\">\n" +
                    "<h1>Welcome to Your Curriculum Support Vault. </h1>\n" +
                    "<h4>Go through the blue links stated in <br> upper pane to navigate through Our resources.</h4>\n" +
                    "  </body>\n" +
                    "</html>\n");
//            editorPane.setText(new DbUtil_University().getUnivPage(RuntimePropertiesExistingUsers.getInstance().getUnivId()));
        }catch(Exception e){
            System.out.println(e);
        }
        if (editorPane.getText().trim().equals("")){
            JOptionPane.showMessageDialog(this, "Information not updated");
        }

        JScrollPane scrollPane=new JScrollPane(editorPane);
        welcomePanel.add(scrollPane);
        welcomePanel.setSize(screen_width, screen_height-155);
        welcomePanel.setLocation(0, 155);
        welcomePanel.setVisible(true);

        return welcomePanel;
    }





    @Override
    public void mouseClicked(MouseEvent e) {
    if(e.getComponent().getName().equals("University Details")){
    super.removeAll();
    super.add(topPanel());
    super.add(univPane());
    }
    if (e.getComponent().getName().equals("Course Details")){
        super.removeAll();
        super.add(topPanel());
        super.add(coursePane());
    }
    if (e.getComponent().getName().equals("Reset Info. Panel")){
        super.removeAll();
        super.add(topPanel());
        super.add(welcome());
    }
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
