package curriculum.support.GuiUtil.User;

import curriculum.support.DbUtil.DbUtil_User;
import curriculum.support.DbUtil.RuntimePropertiesNewUser;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Vector;

public class AddUserDetails extends JInternalFrame implements ActionListener, MouseListener {
    private static AddUserDetails instance = new AddUserDetails();

    public static AddUserDetails getAddUserDetailsInstance() {
        return instance;
    }

    private JLabel nameLabel = null;
    private JTextField nameTextField = null;

    private JLabel dobLabel = null;
    private JTextField dobTextField = null;

    private JLabel addressLabel = null;
    private JTextField addressText = null;

    private JLabel city = null;
    private JTextField addressCity = null;

    private JLabel state = null;
    private JComboBox addressState = null;

    private JLabel genderLabel = null;
    private JComboBox gender = null;

    private JLabel contactLabel = null;
    private JTextField contactTextField = null;

    private JLabel universityLabel = null;
    private JComboBox universityList = null;

    private JLabel instituteLabel = null;
    private JComboBox instituteList = null;

    private JPanel imagePanel = null;

    private JLabel coursLabel = null;
    private JComboBox courseList = null;

    private JLabel brachLabel = null;
    private JComboBox branchList = null;

    private JButton submitButton2 = null;

    DbUtil_User objectInAddUserDetails = new DbUtil_User();

    public AddUserDetails() {
        super("Add Account Details", true, true);
        setLayout(new GridLayout(1, 2, 0, 0));
        setBackground(new Color(255, 255, 255));


        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int screen_width = (int) dim.getWidth();
        int screen_height = (int) dim.getHeight();
        setSize(1490, 555);
        setLocation(5, 5);

        nameLabel = new JLabel("<html><Font color=black size=3><b>Name<Font color=red size=3><b>*<b></font> :</b></font></html>");
        nameTextField = new JTextField();
        nameTextField.setSize(100, 25);


        addressLabel = new JLabel("<html><Font color=black size=3><b>Address<Font color=red size=3><b>*<b></font> :</b></font></html>");
        addressText = new JTextField();

        city = new JLabel("<html><Font color=black size=3><b>City<Font color=red size=3><b>*<b></font> :</b></font></html>");
        addressCity = new JTextField();

        state = new JLabel("<html><Font color=black size=3><b>State<Font color=red size=3><b>*<b></font> :</b></font></html>");
        addressState = new JComboBox(addStates());


        dobLabel = new JLabel("<html><Font color=black size=3><b>Date of Birth(YYYY-MM-DD) <Font color=red size=3><b>*<b></font>:</b></font></html>");
        dobTextField = new JTextField();

        genderLabel = new JLabel("<html><Font color=black size=3><b>Gender<Font color=red size=3><b>*<b></font>  :</b></font></html>");
        gender = new JComboBox(addGender());

        universityLabel = new JLabel("<html><Font color=black size=3><b>University<Font color=red size=3><b>*<b></font> :</b></font></html>");
        Vector uniList = objectInAddUserDetails.addUniList();
        universityList = new JComboBox(uniList);
        universityList.addActionListener(this);

        instituteLabel = new JLabel("<html><Font color=black size=3><b>Institue<Font color=red size=3><b>*<b></font> :</b></font></html>");
        instituteList = new JComboBox();
        instituteList.setEnabled(false);
        instituteList.addActionListener(this);

        coursLabel = new JLabel("<html><Font color=black size=3><b>Course<Font color=red size=3><b>*<b></font> :</b></font></html>");
        courseList = new JComboBox();
        courseList.setEnabled(false);
        courseList.addActionListener(this);

        brachLabel = new JLabel("<html><Font color=black size=3><b>Branch<Font color=red size=3><b>*<b></font> :</b></font></html>");
        branchList = new JComboBox();
        branchList.setEnabled(false);
        branchList.addActionListener(this);

        contactLabel=new JLabel("<html><Font color=black size=3><b>Contact<Font color=red size=3><b>*<b></font> :</b></font></html>");
        contactTextField=new JTextField();
        contactTextField.addActionListener(this);

        submitButton2 = new JButton("Submit");
        submitButton2.addActionListener(this);
        submitButton2.setCursor(new Cursor(Cursor.HAND_CURSOR));
        submitButton2.setActionCommand("submit2");
        JLabel space1 = new JLabel("<html><Font color=black size=2><b><Font color=red size=3><b>*<b></font> - States that these requirements are necessary</b></font></html");

        JPanel userDetails = new JPanel();
        userDetails.setLayout(new GridLayout(12, 2, 5, 5));
        userDetails.setBackground(new Color(255, 255, 255));
        userDetails.add(nameLabel);
        userDetails.add(nameTextField);
        userDetails.add(dobLabel);
        userDetails.add(dobTextField);
        userDetails.add(addressLabel);
        userDetails.add(addressText);
        userDetails.add(city);
        userDetails.add(addressCity);
        userDetails.add(state);
        userDetails.add(addressState);
        userDetails.add(contactLabel);
        userDetails.add(contactTextField);
        userDetails.add(genderLabel);
        userDetails.add(gender);
        userDetails.add(universityLabel);
        userDetails.add(universityList);
        userDetails.add(instituteLabel);
        userDetails.add(instituteList);
        userDetails.add(coursLabel);
        userDetails.add(courseList);
        userDetails.add(brachLabel);
        userDetails.add(branchList);

        userDetails.add(submitButton2);
        userDetails.add(space1);

        add(setImagePanel());
        add(userDetails);

        setVisible(true);

    }

    private JPanel setImagePanel() {
        JLabel imageLabel = new JLabel(new ImageIcon("resource/addUserDetails.jpg"));
        imageLabel.setSize(50, 100);
        imageLabel.setBackground(new Color(255, 255, 255));

        imagePanel = new JPanel();
        imagePanel.setBackground(Color.WHITE);
        imagePanel.setLayout(new BorderLayout());
        imagePanel.add(imageLabel,BorderLayout.CENTER);

        return imagePanel;
    }

    public Vector addGender() {
        Vector genderList = new Vector();
        genderList.add("Select Gender");
        genderList.add("Female");
        genderList.add("Male");
        genderList.add("Others");

        return genderList;
    }


    public Vector addStates() {
        Vector stateList = new Vector();
        stateList.add("Select State");
        stateList.add("Andaman and Nicobar Islands union territory\tPort Blair");
        stateList.add("Andhra Pradesh");
        stateList.add("Arunachal Pradesh");
        stateList.add("Assam");
        stateList.add("Bihar");
        stateList.add("Chandigarh");
        stateList.add("Chhattisgarh");
        stateList.add("Dadra and Nagar Haveli and Daman and Diu union territory");
        stateList.add("New Delhi");
        stateList.add("Goa");
        stateList.add("Gujarat");
        stateList.add("Haryana");
        stateList.add("Himachal Pradesh");
        stateList.add("Jammu and Kashmir union territory");
        stateList.add("Jharkhand");
        stateList.add("Karnataka");
        stateList.add("Kerala");
        stateList.add("Kerala");
        stateList.add("Lakshadweep union territory");
        stateList.add("Madhya Pradesh");
        stateList.add("Maharashtra");
        stateList.add("Manipur");
        stateList.add("Meghalaya");
        stateList.add("Mizoram");
        stateList.add("Nagaland");
        stateList.add("Odisha");
        stateList.add("Puducherry");
        stateList.add("Punjab");
        stateList.add("Rajasthan");
        stateList.add("Sikkim");
        stateList.add("Tamil Nadu");
        stateList.add("Telangana");
        stateList.add("Tripura");
        stateList.add("Uttar Pradesh");
        stateList.add("Uttarakhand");
        stateList.add("West Bengal");


        return stateList;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        /*
         * Action Listner for the University related components such as
         * -> University
         * -> Institute
         * -> Courses
         * -> Branch
         *
         */

        if (e.getSource() == universityList) {
            RuntimePropertiesNewUser.getInstance().setUnivName(null);
            RuntimePropertiesNewUser.getInstance().setUnivName(universityList.getSelectedItem().toString());
            if (!(RuntimePropertiesNewUser.getInstance().getUnivName().contentEquals("Select University"))) {

                String name = RuntimePropertiesNewUser.getInstance().getUnivName();
                RuntimePropertiesNewUser.getInstance().setUnivCode(objectInAddUserDetails.getUniversityCode(name));

                instituteList.removeAllItems();
                ArrayList<String> v = objectInAddUserDetails.getInstitutesForUniv(name);
                for (int i = 0; i < v.size(); i++) {
                    instituteList.addItem(v.get(i));
                }
                instituteList.setEnabled(true);
            }
            if (RuntimePropertiesNewUser.getInstance().getUnivName().contentEquals("Select University")) {
                branchList.setEnabled(false);
                courseList.setEnabled(false);
                instituteList.setEnabled(false);

                branchList.removeAllItems();
                courseList.removeAllItems();
                instituteList.removeAllItems();


            }
        }

        if (e.getSource() == instituteList) {

            System.out.println(RuntimePropertiesNewUser.getInstance().getInstName());
            RuntimePropertiesNewUser.getInstance().setInstName("Select Institute");
            System.out.println(RuntimePropertiesNewUser.getInstance().getInstName());
            try{
                RuntimePropertiesNewUser.getInstance().setInstName(instituteList.getSelectedItem().toString());
            }catch(Exception nullPointerEXception){
                System.out.println(nullPointerEXception);
            }

            if (!(RuntimePropertiesNewUser.getInstance().getInstName().equals("Select Institute"))) {
                String instituteName = RuntimePropertiesNewUser.getInstance().getInstName();
               RuntimePropertiesNewUser.getInstance().setInstCode(objectInAddUserDetails.getInstituteCode(instituteName));
                courseList.removeAllItems();
                ArrayList<String> courses = objectInAddUserDetails.getCourseForInstitute(instituteName);

                for (int i = 0; i < courses.size(); i++) {
                    courseList.addItem(courses.get(i));
                }
                courseList.setEnabled(true);
            }
            if ((RuntimePropertiesNewUser.getInstance().getInstName().equals("Select Institute"))) {
                branchList.setEnabled(false);
                courseList.setEnabled(false);

                branchList.removeAllItems();
                courseList.removeAllItems();

            }
        }

        if(e.getSource()==courseList){
            RuntimePropertiesNewUser.getInstance().setCourseName("Select Course");
            RuntimePropertiesNewUser.getInstance().setCourseName(courseList.getSelectedItem().toString());
            if(!(RuntimePropertiesNewUser.getInstance().getCourseName().equals("Select Course"))){
                try {
                    RuntimePropertiesNewUser.getInstance().setCourseName(courseList.getSelectedItem().toString());
                    System.out.println(RuntimePropertiesNewUser.getInstance().getCourseName());
                    RuntimePropertiesNewUser.getInstance().setCourseCode(objectInAddUserDetails.getCourseCode(RuntimePropertiesNewUser.getInstance().getCourseName()));
                    ArrayList<String> branches = objectInAddUserDetails.getBranchForCourse(RuntimePropertiesNewUser.getInstance().getCourseName());

                    for (int i = 0; i < branches.size(); i++) {
                        branchList.addItem(branches.get(i));
                    }
                    branchList.setEnabled(true);
                }catch(Exception ev){
                    System.out.println(ev);
                }
            }
            if(RuntimePropertiesNewUser.getInstance().getCourseName().equals("Select Course")){
                branchList.setEnabled(false);
                branchList.removeAllItems();
            }
        }

        if(e.getSource()==branchList){
            RuntimePropertiesNewUser.getInstance().setBrachName("Select Branch");
            RuntimePropertiesNewUser.getInstance().setBrachName(branchList.getSelectedItem().toString());
            RuntimePropertiesNewUser.getInstance().setBranchCode(objectInAddUserDetails.getBranchCode(RuntimePropertiesNewUser.getInstance().getBrachName()));
        }


        /*
         * Action Command for submit Button
         */
        if (e.getActionCommand().equals("submit2")) {
            if (!(nameTextField.getText().trim().equals(""))) {

                RuntimePropertiesNewUser.getInstance().setName(null);
                RuntimePropertiesNewUser.getInstance().setName(nameTextField.getText());

                if (!(dobTextField.getText().trim().equals(""))) {

                    RuntimePropertiesNewUser.getInstance().setDob(null);
                    RuntimePropertiesNewUser.getInstance().setDob(dobTextField.getText());

                    if (!(addressText.getText().trim().equals(""))) {

                        RuntimePropertiesNewUser.getInstance().setAddress(null);
                        RuntimePropertiesNewUser.getInstance().setAddress(addressText.getText());

                        if (!(addressCity.getText().trim().equals(""))) {

                            RuntimePropertiesNewUser.getInstance().setCity(null);
                            RuntimePropertiesNewUser.getInstance().setCity(addressCity.getText());

                            if (!(addressState.getSelectedItem().equals("Select State"))) {

                                RuntimePropertiesNewUser.getInstance().setState(null);
                                RuntimePropertiesNewUser.getInstance().setState(addressState.getSelectedItem().toString());

                                if (!(contactTextField.getText().trim().equals(""))) {

                                    RuntimePropertiesNewUser.getInstance().setContact(null);
                                    RuntimePropertiesNewUser.getInstance().setContact(contactTextField.getText());

                                     if (!(gender.getSelectedItem().equals("Select Gender"))) {

                                         RuntimePropertiesNewUser.getInstance().setGender(null);
                                         RuntimePropertiesNewUser.getInstance().setGender(gender.getSelectedItem().toString());

                                        if (!(universityList.getSelectedItem().equals("Select University"))) {

                                            if (!(instituteList.getSelectedItem().equals("Select Institute"))) {

                                                if (!(courseList.getSelectedItem().equals("Select Course"))) {

                                                    if (!(branchList.getSelectedItem().equals("Select Branch"))) {
                                                        try {
                                                            System.out.println(RuntimePropertiesNewUser.getInstance().getName());
                                                            System.out.println(RuntimePropertiesNewUser.getInstance().getDob());
                                                            System.out.println(RuntimePropertiesNewUser.getInstance().getGender());
                                                            System.out.println(RuntimePropertiesNewUser.getInstance().getAddress());
                                                            System.out.println(RuntimePropertiesNewUser.getInstance().getCity());
                                                            System.out.println(RuntimePropertiesNewUser.getInstance().getState());
                                                            System.out.println(RuntimePropertiesNewUser.getInstance().getContact());
                                                            System.out.println(RuntimePropertiesNewUser.getInstance().getUnivName()+RuntimePropertiesNewUser.getInstance().getUnivCode());
                                                            System.out.println(RuntimePropertiesNewUser.getInstance().getInstName()+RuntimePropertiesNewUser.getInstance().getInstCode());
                                                            System.out.println(RuntimePropertiesNewUser.getInstance().getCourseName()+RuntimePropertiesNewUser.getInstance().getCourseCode());
                                                            System.out.println(RuntimePropertiesNewUser.getInstance().getBrachName()+RuntimePropertiesNewUser.getInstance().getBranchCode());
                                                            System.out.println(RuntimePropertiesNewUser.getInstance().getEmail_id());
                                                        }catch(Exception ev){
                                                            System.out.println(ev);
                                                        }
                                                        objectInAddUserDetails.addUserValues(RuntimePropertiesNewUser.getInstance().getEmail_id(),
                                                                RuntimePropertiesNewUser.getInstance().getName(),
                                                                RuntimePropertiesNewUser.getInstance().getDob(),
                                                                RuntimePropertiesNewUser.getInstance().getContact(),
                                                                RuntimePropertiesNewUser.getInstance().getAddress(),
                                                                RuntimePropertiesNewUser.getInstance().getCity(),
                                                                RuntimePropertiesNewUser.getInstance().getState(),
                                                                RuntimePropertiesNewUser.getInstance().getGender(),
                                                                RuntimePropertiesNewUser.getInstance().getUnivCode(),
                                                                RuntimePropertiesNewUser.getInstance().getInstCode(),
                                                                RuntimePropertiesNewUser.getInstance().getCourseCode(),
                                                                RuntimePropertiesNewUser.getInstance().getBranchCode());
                                                        JOptionPane.showMessageDialog(this, "Your Account has been created. Go to Home Tab to login. ");
                                                       super.setVisible(false);
                                                } else {
                                                    JOptionPane.showMessageDialog(this, "Select Branch before submitting.");
                                                }
                                            } else {
                                                JOptionPane.showMessageDialog(this, "Select Course before submitting.");
                                            }
                                        } else {
                                            JOptionPane.showMessageDialog(this, "Select Institute before submitting.");
                                        }

                                    } else {
                                        JOptionPane.showMessageDialog(this, "Select University before submitting.");
                                    }
                                } else {
                                    JOptionPane.showMessageDialog(this, "Select Gender before submitting.");
                                }
                            }else{
                                    JOptionPane.showMessageDialog(this, "Enter Contact Details before submitting.");
                                }
                            } else {
                                JOptionPane.showMessageDialog(this, "Select State before submitting.");
                            }
                        } else {
                            JOptionPane.showMessageDialog(this, "Enter your City before submitting.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Enter address before submitting.");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Enter DOB before submitting.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Enter Name before submitting.");
            }
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
