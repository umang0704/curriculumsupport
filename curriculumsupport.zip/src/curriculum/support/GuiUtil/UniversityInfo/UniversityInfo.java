package curriculum.support.GuiUtil.UniversityInfo;

import curriculum.support.DbUtil.DbUtil_University;
import javax.swing.*;
import java.awt.*;


public class UniversityInfo extends Panel {
    JEditorPane editorPane=null;
    JScrollPane scrollPane=null;
    String univCodePara=null;
    public UniversityInfo(String univCode){
        super(new BorderLayout());
        univCodePara=univCode;
        add(addUniversityPage());
        setVisible(true);
    }

    public JScrollPane addUniversityPage(){
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int screen_width= (int)dim.getWidth();
        int screen_height= (int)dim.getHeight();
        editorPane=new JEditorPane();
        editorPane.setEditable(false);

        try{
            editorPane.setContentType("text/html");
            editorPane.setText(new DbUtil_University().getUnivPage(univCodePara));
        }catch(Exception e){
            System.out.println(e);
        }
        if (editorPane.getText().trim().equals("")){
            JOptionPane.showMessageDialog(this, "Information not updated");
        }
        scrollPane=new JScrollPane(editorPane);
        scrollPane.setSize(screen_width-10,screen_height-10);
        return scrollPane;
    }

}
