package curriculum.support.GuiUtil.HomeWindow;

import curriculum.support.DbUtil.MarqueeLabel;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class Notice extends JPanel {

    private JLabel imageLabel=null;
    private static Notice instanceNotice=null;
    private static Notice getNoticeInstance(){
        if(instanceNotice==null)
            instanceNotice=new Notice();
        return instanceNotice;
    }
    public Notice(){
        super(new BorderLayout());

        TitledBorder titledBorder=new TitledBorder("<html><Font color=black size=3><b>Notice:</b></font></html>");
        setBorder(titledBorder);
        setBackground(Color.white);


        JPanel noticePanel=new JPanel();
        noticePanel.setBackground(Color.WHITE);
        JLabel jep = new MarqueeLabel("<html><Font color=black size=3><b>-><br>-><br>Welcome to NOTICEs of CURRICULUM SUPPORT...<br>- Here you could get the link to UGC <br>- University could upload their notice for students directly.<br>-><br>-></b></font></html>", MarqueeLabel.TOP_TO_BOTTOM, 100);
        noticePanel.add(jep);

        JPanel imagePanlel=new JPanel();
        imagePanlel.add(imageLabel());


        add(imagePanlel,BorderLayout.WEST);
        add(noticePanel,BorderLayout.CENTER);

        setVisible(true);
    }
    public JLabel imageLabel(){
        imageLabel=new JLabel(new ImageIcon("resource/Notices.jpg"));
        imageLabel.setSize(200,200);
        return imageLabel;
    }
}
