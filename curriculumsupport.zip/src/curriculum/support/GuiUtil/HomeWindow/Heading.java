package curriculum.support.GuiUtil.HomeWindow;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Heading extends JPanel implements ActionListener {

    private JLabel imageLabel=null;

    private static Heading instanceHeading=null;
    public static Heading getHeadingInstance(){
        if(instanceHeading==null)
            instanceHeading=new Heading();
        return instanceHeading;
    }


    public Heading(){
        setLayout(new BorderLayout());
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int screen_width= (int)dim.getWidth();
        int screen_height= (int)dim.getHeight();
        setSize(screen_width,((int)dim.getHeight()/2)-250);
        setBackground(Color.white);
        TitledBorder titledBorder=new TitledBorder("<html><Font color=black size=3><b>Welcome to Curriculum Support</b></font></html>");
        setBorder(titledBorder);

//
//
//        JPanel southNorth=new JPanel();
//        southNorth.setLayout(new BorderLayout());
//        southNorth.setBackground(Color.BLACK);
//        JButton closeButton=new JButton("<html><Font color=black size=2>Exit Tab</font></html>");
//        closeButton.setActionCommand("exittab");
//        closeButton.addActionListener(this);
//        southNorth.add(closeButton,BorderLayout.NORTH);


        JLabel curriculum=new JLabel("<html><Font color=red size=30><i>CURRICULUM</i></font></html>");
        JLabel support=new JLabel("<html><Font color=red size=30><i><b>SUPPORT</b></i></font></html>");
        JPanel imagePanel=new JPanel();
        imagePanel.setSize(screen_width/3,(screen_height/16)*6);
        imagePanel.add(curriculum);
        imagePanel.add(imageLabel());
        imagePanel.add(support);
        imagePanel.setBackground(Color.black);

        add(imagePanel,BorderLayout.CENTER);
//        add(southNorth,BorderLayout.EAST);

        setLocation(1,1);
        setVisible(true);

    }
    public JLabel imageLabel(){
        Border redLine=BorderFactory.createLineBorder(Color.RED);

        imageLabel=new JLabel(new ImageIcon("resource/logo.png"));
        imageLabel.setSize(200,200);
        imageLabel.setBorder(redLine);
        return imageLabel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
