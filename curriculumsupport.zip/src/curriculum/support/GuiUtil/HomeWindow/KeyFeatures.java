package curriculum.support.GuiUtil.HomeWindow;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class KeyFeatures extends JPanel{
    private JLabel imageLabel=null;
    private JPanel keyFeaturesPanel=null;

    private static KeyFeatures instanceKeyFeatures=null;
    public static KeyFeatures getKeyFeautureInstance(){
        if(instanceKeyFeatures==null)
            instanceKeyFeatures=new KeyFeatures();
        return instanceKeyFeatures;
    }

    public KeyFeatures(){

        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int screen_width= (int)dim.getWidth();
        int screen_height= (int)dim.getHeight();
        setSize(((int)dim.getWidth()/3)-1,374);
        setLayout(new GridLayout(2,1,10,10));
        setBackground(Color.white);
        TitledBorder titledBorder=new TitledBorder("<html><Font color=black size=3><b>Key Features:</b></font></html>");
        setBorder(titledBorder);

        JPanel imagePanel=new JPanel();
        imagePanel.setSize((screen_width/3)-1,((screen_height/16)*6)-1);
        imagePanel.add(imageLabel());
        imagePanel.setBackground(Color.WHITE);


        JPanel keyFeatures=new JPanel();
        keyFeatures.add(addKeyFeaturePanel());

        add(imagePanel);
        add(keyFeatures);



        setLocation(((int)dim.getWidth()/3)*2,((int)dim.getHeight()/2)-250);

        setVisible(true);
    }

    public JLabel imageLabel(){
        imageLabel=new JLabel(new ImageIcon("resource/KeyFeatyres.png"));
        imageLabel.setSize(200,200);
        return imageLabel;
    }
    public JPanel addKeyFeaturePanel(){
        keyFeaturesPanel=new JPanel();
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int screen_width= (int)dim.getWidth();
        int screen_height= (int)dim.getHeight();
        keyFeaturesPanel.setSize((screen_width/3), (screen_height/16)*10);


        return keyFeaturesPanel;
    }
}
