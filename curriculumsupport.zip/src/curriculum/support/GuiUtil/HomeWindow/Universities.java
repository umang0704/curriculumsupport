package curriculum.support.GuiUtil.HomeWindow;

import curriculum.support.DbUtil.DbUtil_User;
import curriculum.support.GuiUtil.UniversityInfo.UniversityInfo;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;

public class Universities extends JPanel implements MouseListener {
    private JLabel imageLabel=null;
    private JPanel university=null;

    DbUtil_User objDbUtilUser=new DbUtil_User();
    JLabel[] univLabel=null;

    private static Universities instanceUniversities=null;
    private static Universities getInstanceUniversities(){
        if(instanceUniversities==null)
            instanceUniversities=new Universities();
        return instanceUniversities;

    }
    public Universities(){

        //Creating Panel
        setLayout(new BorderLayout());
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int screen_width= (int)dim.getWidth();
        int screen_height= (int)dim.getHeight();
        setSize(((int)dim.getWidth()/3),375);
        setBackground(Color.white);
        TitledBorder titledBorder=new TitledBorder("<html><Font color=black size=3><b>University List:</b></font></html>");
        setBorder(titledBorder);


        //adding Image
        JPanel imagePanel=new JPanel();
        imagePanel.setSize((screen_width/3)-1,((screen_height/16)*6)-1);
        imagePanel.add(imageLabel());
        imagePanel.setBackground(Color.WHITE);


        add(imagePanel,BorderLayout.NORTH);
        add(addUniversityListPanel(),BorderLayout.CENTER);

        setLocation(1,((int)dim.getHeight()/2)-249);

        setVisible(true);
    }

    public JLabel imageLabel(){
        imageLabel=new JLabel(new ImageIcon("resource/university.png"));
        imageLabel.setSize(200,200);
        return imageLabel;
    }

    public JPanel addUniversityListPanel(){
        university=new JPanel();
        addUnivLabel(university);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int screen_width= (int)dim.getWidth();
        int screen_height= (int)dim.getHeight();
        university.setSize((screen_width/3), (screen_height/16)*10);


        return university;
    }
    public void addUnivLabel(JPanel panel){
        Vector<String> v=objDbUtilUser.addUniList();
        panel.setLayout(new GridLayout(v.size(), 1, 1,1 ));
        univLabel=new JLabel[v.size()];
        for(int i=1;i<v.size();i++){
            univLabel[i]=new JLabel(v.get(i));
            univLabel[i].setForeground(Color.BLUE);
           univLabel[i].addMouseListener(this);
            univLabel[i].setCursor(new Cursor(Cursor.HAND_CURSOR));
            univLabel[i].setName(v.get(i));
            panel.add(univLabel[i]);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getComponent().getName().equals(univLabel[1].getText())){
            HomeTab.getInstanceHomeTab().addTab(univLabel[1].getText(),
                    new UniversityInfo(objDbUtilUser.getUniversityCode(univLabel[1].getText())));
        }

        if(e.getComponent().getName().equals(univLabel[2].getText())){
            HomeTab.getInstanceHomeTab().addTab(univLabel[2].getText(),new UniversityInfo(objDbUtilUser.getUniversityCode(univLabel[2].getText())));
        }

    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
