package curriculum.support.GuiUtil.HomeWindow;

import curriculum.support.DbUtil.DbUtil_User;
import curriculum.support.DbUtil.RuntimePropertiesExistingUsers;
import curriculum.support.GuiUtil.User.AccountDetail;
import curriculum.support.GuiUtil.User.UserRegistration;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LogInWindow extends JPanel implements ActionListener {

    private String enteredEmail;
    private String enteredPassword;

    private static LogInWindow instanceLoginWindow=null;
    public static LogInWindow getLoginWindowInstance(){
        if(instanceLoginWindow==null){
            instanceLoginWindow=new LogInWindow();
        }
        return instanceLoginWindow;
    }

    private JPanel loginDetailsPanel = null;
    private JLabel username = null;
    private JTextField usernameText = null;
    private JLabel password = null;
    private JPasswordField passwordField = null;


    private JButton signIn = null;
    private JButton signUp = null;

    private JPanel wholeWindowPane = null;
    private JLabel imageLabel = null;


    public LogInWindow() {

        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((((int) dim.getWidth() / 2) - 256),
                ((int) dim.getHeight() / 2) - 250);
        setLayout(new BorderLayout());
        setBackground(Color.white);
        TitledBorder titledBorder = new TitledBorder("<html><Font color=black size=3><b>Log In/Authentication</b></font></html>");
        setBorder(titledBorder);


        JPanel imagePanel = new JPanel();
        imagePanel.setLayout(new BorderLayout());
        imagePanel.add(imageLabel(),
                BorderLayout.CENTER);
        imagePanel.setSize(200,
                300);
        imagePanel.setBackground(Color.WHITE);


        JPanel authenticationPanel = new JPanel();
        authenticationPanel.setLayout(new GridLayout(1,
                1,
                0,
                0));
        authenticationPanel.add(addLogInDetailsPanel());


        wholeWindowPane = new JPanel();
        wholeWindowPane.setLayout(new BorderLayout());
        wholeWindowPane.add(imagePanel,
                BorderLayout.CENTER);
        wholeWindowPane.add(authenticationPanel,
                BorderLayout.SOUTH);
        wholeWindowPane.setSize(200,
                170);


        add(wholeWindowPane,
                BorderLayout.CENTER);


        setSize(((int) dim.getWidth() / 3),
                375);


        setVisible(true);

    }

    public JLabel imageLabel() {
        imageLabel = new JLabel(new ImageIcon("resource/user-authentication.jpg"));
        imageLabel.setSize(200,
                200);
        return imageLabel;
    }

    public JPanel addLogInDetailsPanel() {

        loginDetailsPanel = new JPanel();
        loginDetailsPanel.setLayout(new GridLayout(3,
                2,
                10,
                10));
        loginDetailsPanel.setSize(150,
                50);

        username = new JLabel("Email:");
        username.setEnabled(true);

        usernameText = new JTextField();
        usernameText.setEnabled(true);

        password = new JLabel("Password:");
        password.setEnabled(true);

        passwordField = new JPasswordField();
        passwordField.setEnabled(true);

        signIn = new JButton("Sign In");
        signIn.setEnabled(true);
        signIn.setSize(20,
                20);

        signUp = new JButton("New User");
        signUp.setEnabled(true);
        signUp.setSize(20,
                20);


        loginDetailsPanel.add(username);
        loginDetailsPanel.add(usernameText);
        loginDetailsPanel.add(password);
        loginDetailsPanel.add(passwordField);

        loginDetailsPanel.add(signUp);
        signUp.setCursor(new Cursor(Cursor.HAND_CURSOR));
        signUp.addActionListener(this);
        signUp.setActionCommand("signup");

        loginDetailsPanel.add(signIn);
        signIn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        signIn.addActionListener(this);
        signIn.setActionCommand("signin");

        return loginDetailsPanel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getActionCommand().equals("signin")) {

            if(!(usernameText.getText().trim().equals("")) && !(passwordField.getText().trim().equals(""))){
                enteredEmail=usernameText.getText();
                enteredPassword=passwordField.getText();
                RuntimePropertiesExistingUsers.getInstance().setEmail(enteredEmail);

                 DbUtil_User objDbUtilUser1 =new DbUtil_User();

            if(objDbUtilUser1.getAuthentication(enteredEmail, enteredPassword)){
                objDbUtilUser1.retrieveAccountDetails(enteredEmail);
                HomeTab.getInstanceHomeTab().addTab(RuntimePropertiesExistingUsers.getInstance().getName(),
                        new AccountDetail());
            }
            else{
                    JOptionPane.showMessageDialog(this,
                            "No such account is found, Please check Email Id or Password.");
                    usernameText.setText("");
                    passwordField.setText("");
                }
            }
            else{
                    JOptionPane.showMessageDialog(this,
                            "Please Enter the required account details to Sing In");
                }
        }
        else if(e.getActionCommand().equals("signup")){
            usernameText.setText("");
            passwordField.setText("");
            HomeTab.getInstanceHomeTab().addTab("Registration",
                    new UserRegistration());
        }
    }
}
