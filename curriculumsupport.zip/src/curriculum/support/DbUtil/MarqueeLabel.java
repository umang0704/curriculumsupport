package curriculum.support.DbUtil;

import java.awt.Graphics;
import javax.swing.JLabel;
public class MarqueeLabel extends JLabel {
    public static int LEFT_TO_RIGHT = 1;
    public static int RIGHT_TO_LEFT = 2;
    public static int TOP_TO_BOTTOM = 4;
    String text;
    int Option;
    int Speed;
    public MarqueeLabel(String text, int Option, int Speed) {
        this.Option = Option;
        this.Speed = Speed;
        this.setText(text);
    }
    @Override
    protected void paintComponent(Graphics g) {
        if (Option == LEFT_TO_RIGHT) {
            g.translate((int) ((System.currentTimeMillis() / Speed) % (getWidth() * 2) - getWidth()), 0);
        } else if (Option == RIGHT_TO_LEFT) {
            g.translate((int) (getWidth() - (System.currentTimeMillis() / Speed) % (getWidth() * 2)), 0);
        }
        else if (Option==TOP_TO_BOTTOM){
            g.translate(0,(int)((System.currentTimeMillis()/Speed)%(getHeight()*2)-getHeight()));
        }
        super.paintComponent(g);
        repaint(5);
    }
}
