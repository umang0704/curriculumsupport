package curriculum.support.DbUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class DbUtil_University {
    private Connection con=null;



    public String getUnivPage(String univId) {

        String htmlFile = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT universityInfoPage FROM curriculumsupport.university WHERE uni_id='" + univId + "';");



            while (rs.next()) {
                htmlFile=rs.getString("universityInfoPage");
            }
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return htmlFile;
    }
    public String getCoursePage(String courseId) {

        String htmlFile = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT courseInfoPage FROM curriculumsupport.courses WHERE course_id='" + courseId + "';");



            while (rs.next()) {
                htmlFile=rs.getString("courseInfoPage");
            }
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return htmlFile;
    }
}
