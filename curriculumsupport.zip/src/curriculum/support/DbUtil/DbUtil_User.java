package curriculum.support.DbUtil;
import curriculum.support.GuiUtil.User.AddUserDetails;

import java.sql.*;
import java.util.ArrayList;
import java.util.Vector;

public class DbUtil_User {

    public static boolean authStatus = false;
    public static boolean concurrencyStatus = false;
    private static boolean addNewUser=false;
   // String uni_code;
    public Connection con = null;
    String courseId;

    public  boolean getAuthentication(String userName, String password) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement s1 = con.createStatement();
            ResultSet rs = s1.executeQuery("select * from curriculumsupport.users ");


            while (rs.next()) {
                if (userName.trim().equals(rs.getString("email_id")) && password.equals(rs.getString("password"))) {
                    authStatus = true;
                    break;
                } else {
                    authStatus = false;
                }
            }
            con.close();

        } catch (Exception e) {
            System.out.println(e);
        }

        return authStatus;
    }


    /*
     * Email verification for
     * the new User Registration.
     */
    public boolean uniqueUserAuthentication(String email) {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement checkConcurrency = con.createStatement();
            ResultSet rs= checkConcurrency.executeQuery("select * from curriculumsupport.users where email_id='"+email+"'");

            if (rs.next()) {
                System.out.println(rs.getString(1));

            }else {
                concurrencyStatus=true;

            }



            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return concurrencyStatus;
    }

    /*

     */
    public boolean addUniqueUserDetails(String email,String password){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement addEmailStatement=con.createStatement();
            String query="insert into curriculumsupport.users values('"+email+"','"+password+"');";
            int added=addEmailStatement.executeUpdate(query);
            if(added==1){
                addNewUser=true;
            }
            else{
                addNewUser=false;
            }
            con.close();
        }catch(Exception e){
            System.out.println(e);
        }
        return addNewUser;
    }
    /*
     * Boolean method to
     * add new user account details.
     */
    public boolean addUserValues(String email, String name, String dob,String conatct, String address,String city,String state, String gender, String universityId,String insituteId, String courseId, String BranchId) {
        boolean addedAccountDetails=false;
        String fullAddress=address+", "+city+", "+state;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement addValuesStatement=con.createStatement();
            int added=addValuesStatement.executeUpdate("INSERT INTO `curriculumsupport`.`user_details` (`name`, `address`, `dob`, `uni_id`, `course_id`, `contact`, `gender`, `institute_id`, `email_id`, `branch_id`) VALUES ('"+name+"', '"+fullAddress+"', '"+dob+"', '"+universityId+"', '"+courseId+"', '"+conatct+"', '"+gender+"', '"+insituteId+"', '"+email+"', '"+BranchId+"');");
            if(added==1)
                addedAccountDetails=true;
            else
                addedAccountDetails=false;

            con.close();
        }catch(Exception e){
            System.out.println(e);
        }
        return addedAccountDetails;
    }

    public void retrieveAccountDetails(String email){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement retriveDetailsStatement=con.createStatement();
            ResultSet retriveDetailsResultSet=retriveDetailsStatement.executeQuery("SELECT * FROM curriculumsupport.user_details where email_id='"+email+"';");
            while(retriveDetailsResultSet.next()){
                RuntimePropertiesExistingUsers.getInstance().setName(retriveDetailsResultSet.getString("name"));
                RuntimePropertiesExistingUsers.getInstance().setDob( retriveDetailsResultSet.getString("dob"));
                RuntimePropertiesExistingUsers.getInstance().setAddress(retriveDetailsResultSet.getString("address"));
                RuntimePropertiesExistingUsers.getInstance().setGender(retriveDetailsResultSet.getString("gender"));
                RuntimePropertiesExistingUsers.getInstance().setUser_id(retriveDetailsResultSet.getString("user_id"));
                RuntimePropertiesExistingUsers.getInstance().setCourseId(retriveDetailsResultSet.getString("course_id"));
                RuntimePropertiesExistingUsers.getInstance().setUnivId(retriveDetailsResultSet.getString("uni_id"));
                RuntimePropertiesExistingUsers.getInstance().setInstId(retriveDetailsResultSet.getString("institute_id"));
                RuntimePropertiesExistingUsers.getInstance().setContact(retriveDetailsResultSet.getString("contact"));
                RuntimePropertiesExistingUsers.getInstance().setBranch(retriveDetailsResultSet.getString("branch_id"));


            }
            con.close();
        }catch(Exception e){
            System.out.println(e);
        }
    }

    public void changePassword(String email,String newpassword){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement changePassword=con.createStatement();
            ResultSet rs=changePassword.executeQuery("update curriculumsupport.users set password='"+newpassword+"' where email_id='"+email+"';");
        }catch(Exception e){
            System.out.println(e);
        }
    }


    /*
     * String Method to return the university code from the
     * entered university Name.
     */
    public String getUniversityCode(String uni_name){
        String uni_code = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement getUni_codeStatement=con.createStatement();
            ResultSet get_unicodeResultSet=getUni_codeStatement.executeQuery("select `uni_id` from `curriculumsupport`.`university` where `uni_name`='"+uni_name+"';");
            while(get_unicodeResultSet.next()) {
                uni_code = get_unicodeResultSet.getString("uni_id");
            }
        }catch(Exception e){
            System.out.println(e);
        }
        return uni_code;
    }

    /*
     *String method to return the Institute Code
     * using the passed Institute name.
     */
    public String getInstituteCode(String instituteName){
        String instituteCode = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement getUni_codeStatement=con.createStatement();
            ResultSet get_unicodeResultSet=getUni_codeStatement.executeQuery("select institue_id from curriculumsupport.institue where institue_name='"+instituteName+"';");
            while(get_unicodeResultSet.next()) {
                instituteCode = get_unicodeResultSet.getString("institue_id");
                System.out.println(get_unicodeResultSet.getString("institue_id"));
            }
        }catch(Exception e){
            System.out.println(e);
        }
        return instituteCode;
    }

    /*
     *String method to return the Course Code
     * using the passed Course name.
     */
    public String getCourseCode(String courseName){

        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select course_id from curriculumsupport.courses where course_name='"+courseName+"';");
            while(rs.next()){
                courseId=rs.getString("course_id");
            }
            con.close();
            }catch(Exception e){
            System.out.println(e);
        }
        return courseId;
    }


    /*
     * String method to
     * get branch Codes from Branch Name
     */

    public String getBranchCode(String branchName){
        String branchCode=null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("Select branch_id from curriculumsupport.branch where branch_name='"+branchName+"';");
            while(rs.next()){
                branchCode=rs.getString("branch_id");
            }
        }catch (Exception e){
            System.out.println(e);
        }
        return branchCode;
    }


    /*
     * Vector method for adding List of University into
     * the JCombo Box of University List
     */
    public Vector addUniList(){
        Vector uniList=new Vector();
        uniList.add("Select University");
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement changePassword=con.createStatement();
            ResultSet rs=changePassword.executeQuery("SELECT uni_name FROM curriculumsupport.university;");
            while (rs.next()){
                uniList.add(rs.getString("uni_name"));

            }
            con.close();
        }catch(Exception e){
            System.out.println(e);
        }
        return uniList;
    }

    /*
     * ArrayList for add the Institute Names fetched using the
     * University code which is fetched with the name of the university selected from the
     * University List JCombo Box.
     */
    public ArrayList<String> getInstitutesForUniv(String name){
        String uni_code=getUniversityCode(name);

        ArrayList<String> instList=new ArrayList<>();
        instList.add("Select Institute");

        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("Select institue_name from curriculumsupport.institue where university_id='"+uni_code+"'");
            while(rs.next()){

                instList.add(rs.getString("institue_name"));
                System.out.println(rs.getString("institue_name"));
            }
            con.close();
        }catch(Exception e){
            System.out.println(e);
        }
        return instList;
    }

    /*
     * Array list for adding the Courses
     * for specific institutes using
     * the institute name as the parameter
     *
     */
    public ArrayList<String> getCourseForInstitute(String insName){
        String instituteCode=getInstituteCode(insName);
        ArrayList<String> courseList=new ArrayList<>();
        courseList.add("Select Course");

        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select course_name from curriculumsupport.courses where institue_id='"+instituteCode+"'");
            while(rs.next()){
                //               AddUserDetails.getAddUserDetailsInstance().getInstittuteList().addItem(rs.getString("institue_name"));
                courseList.add(rs.getString("course_name"));
                System.out.println(rs.getString("course_name"));
            }
            con.close();
        }catch(Exception e){
            System.out.println(e);
        }
        return courseList;

    }

    /*
     * Array List for fetching
     * branch name using the
     * course name
     */
    public ArrayList<String> getBranchForCourse(String courseName){
        String courseCode=getCourseCode(courseName);
        ArrayList<String> branchList=new ArrayList<>();
        branchList.add("Select Branch");
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("Select branch_name from curriculumsupport.branch where course_id='"+courseCode+"'");
            while (rs.next()){
                branchList.add(rs.getString("branch_name"));
            }
            con.close();
        }catch(Exception e){
            System.out.println(e);
        }
        return branchList;
    }


    public String getBranchName(String branchcode){
        String branchName=null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("Select branch_name from curriculumsupport.branch where branch_id='"+branchcode+"';");
            while(rs.next()){
                branchName=rs.getString("branch_name");
            }
        }catch (Exception e){
            System.out.println(e);
        }
        return branchName;
    }

    public String getCourseNameFromCode(String courseCode){
        String courseName=null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select course_name from curriculumsupport.courses where course_id='"+courseCode+"';");
            while(rs.next()){
                courseName=rs.getString("course_name");
            }
            con.close();
        }catch(Exception e){
            System.out.println(e);
        }
        return courseName;
    }

    public String getInstituteNameFromCode(String institutecode){
        String instituteName = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement getUni_codeStatement=con.createStatement();
            ResultSet get_unicodeResultSet=getUni_codeStatement.executeQuery("select institue_name from curriculumsupport.institue where institue_id='"+institutecode+"';");
            while(get_unicodeResultSet.next()) {
                instituteName = get_unicodeResultSet.getString("institue_name");

            }
        }catch(Exception e){
            System.out.println(e);
        }
        return instituteName;
    }
    public String getUniversityNameFromCode(String uni_code){
        String uni_Name = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/curriculumsupport", "root", "7april2000");
            Statement getUni_codeStatement=con.createStatement();
            ResultSet get_unicodeResultSet=getUni_codeStatement.executeQuery("select `uni_name` from `curriculumsupport`.`university` where `uni_id`='"+uni_code+"';");
            while(get_unicodeResultSet.next()) {
                uni_Name = get_unicodeResultSet.getString("uni_name");
            }
        }catch(Exception e){
            System.out.println(e);
        }
        return uni_Name;
    }
}
