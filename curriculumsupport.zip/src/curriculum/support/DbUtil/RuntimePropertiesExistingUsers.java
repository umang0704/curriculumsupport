package curriculum.support.DbUtil;

public class RuntimePropertiesExistingUsers {

    private static RuntimePropertiesExistingUsers instance=null;

    public static RuntimePropertiesExistingUsers getInstance(){
        if (instance==null)
            instance=new RuntimePropertiesExistingUsers();
        return instance;
    }

    private String user_id;
    private String name;
    private String address;
    private String dob;
    private String univId;
    private String courseId;
    private String contact;
    private String gender;
    private String instId;
    private String email;
    private String branch;

    private RuntimePropertiesExistingUsers(){

    }
    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getUnivId() {
        return univId;
    }

    public void setUnivId(String univId) {
        this.univId = univId;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getInstId() {
        return instId;
    }

    public void setInstId(String instId) {
        this.instId = instId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }
}
